Jogo feito para a disciplina Organiza��o de Computadores Digitais por
Bruno de Sousa Pagno
Jo�o Victor Mello
Lucas Salibba

Link para Dowload do simulador para Windows:

https://gitlab.com/simoesusp/disciplinas/blob/master/SSC0511-Organizacao-de-Computadores-Digitais/Simulador_Windows_Tudo_Pronto_F%C3%A1cil.zip

Mais informa��es/dowload para outras plataformas encontrados em:

https://gitlab.com/simoesusp/disciplinas/tree/master/SSC0511-Organizacao-de-Computadores-Digitais

Autoria do professor Eduardo do Vale Sim�es
